from flask import Flask, request

app = Flask(__name__)

@app.route('/')
def calculator_form():
    return '''
        <h2>Simple Calculator</h2>
        <form method="post" action="/calculate">
            <input type="number" name="num1" placeholder="Enter first number" required>
            <select name="operation">
                <option value="add">+</option>
                <option value="subtract">-</option>
                <option value="multiply">*</option>
                <option value="divide">/</option>
            </select>
            <input type="number" name="num2" placeholder="Enter second number" required>
            <input type="submit" value="Calculate">
        </form>
    '''

@app.route('/calculate', methods=['POST'])
def calculate():
    num1 = float(request.form['num1'])
    num2 = float(request.form['num2'])
    operation = request.form['operation']

    if operation == 'add':
        result = num1 + num2
    elif operation == 'subtract':
        result = num1 - num2
    elif operation == 'multiply':
        result = num1 * num2
    elif operation == 'divide':
        result = num1 / num2 if num2 != 0 else 'Error: Division by zero'
    else:
        result = 'Invalid operation'

    return f'<h2>Result: {result}</h2><br><a href="/">Try Again</a>'

if __name__ == "__main__":
    app.run(debug=True)
